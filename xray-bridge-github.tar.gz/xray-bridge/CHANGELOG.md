# Changelog

All notable changes to XRay Bridge Panel will be documented in this file.

## [2.1.0] - 2025-05-19

### Added
- 🔒 Authentication system with session-based login
- 🎨 Customizable login page (title, logo, colors) with live preview
- 🌐 Per-config DNS override (each config can have its own DNS)
- ⬇ XRay Core install/uninstall from within the panel with live log
- 💾 Backup and restore (JSON export/import)
- 📊 System stats dashboard (RAM, CPU, uptime)
- 🔄 Restart XRay button
- 📡 XHTTP (SplitHTTP) protocol support
- 🔑 Change username and password from Security page
- ⬡ 3X-UI API integration

### Changed
- Improved delay test loop reliability
- Better SOCKS5 real-delay measurement
- XRay config JSON now includes per-config DNS settings
- Auto-switch now logs which config it switched to

## [2.0.0] - 2025-05-17

### Added
- Full rewrite from scratch
- Real TCP delay testing every N seconds
- Real delay via SOCKS5 proxy
- Auto-switch to best config
- Bulk import (multiple links at once)
- Support for VLESS, VMess, Trojan, ShadowSocks
- Reality, WS, gRPC, H2, XHTTP stream support
- Dark modern UI (self-contained, no CDN)
- XRay config.json builder and viewer
- 3X-UI connection page
- Routing rules (Iran direct, block ads)

## [1.0.0] - 2025-05-15

### Added
- Initial release
- Basic config management
- XRay process management
