#!/usr/bin/env node
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const { execSync, spawn, exec } = require('child_process');
const net = require('net');
const os = require('os');
const crypto = require('crypto');

const DATA_DIR = path.join(__dirname, 'data');
const CONFIG_FILE = path.join(DATA_DIR, 'configs.json');
const SETTINGS_FILE = path.join(DATA_DIR, 'settings.json');
const AUTH_FILE = path.join(DATA_DIR, 'auth.json');
const XRAY_CONFIG_FILE = path.join(DATA_DIR, 'xray_config.json');
const PORT = process.env.PORT || 2054;

let configs = [], settings = {}, auth = {}, sessions = {};
let xrayProcess = null, activeConfigId = null, delayTestInterval = null;
let logs = [], installLog = [], installStatus = 'idle', installProcess = null;

function ensureDataDir() { if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true }); }

function defaultSettings() {
  return {
    socksPort: 10808, httpPort: 10809, autoSwitch: true, autoSwitchInterval: 5,
    logLevel: 'warning', dns1: '1.1.1.1', dns2: '8.8.8.8', localDns: '178.22.122.100',
    mux: true, routeIranDirect: true, blockAds: false, dnsStrategy: 'IPIfNonMatch',
    xrayApiPort: 10085, xuiUrl: 'http://localhost:2053', xuiUser: '', xuiPass: '',
    loginTitle: 'XRay Bridge Panel', loginSubtitle: 'مدیریت تانل هوشمند',
    loginLogo: '⛓', loginBg: '#080c14', loginAccent: '#3d8ef8',
    loginShowVersion: true, loginBgImage: '', loginCustomCss: '',
    panelTitle: 'XRay Bridge',
  };
}

function loadData() {
  ensureDataDir();
  try { configs = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')); } catch { configs = []; }
  try { settings = { ...defaultSettings(), ...JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8')) }; }
  catch { settings = defaultSettings(); saveSettings(); }
  try { auth = JSON.parse(fs.readFileSync(AUTH_FILE, 'utf8')); }
  catch {
    auth = { users: [{ username: 'admin', password: hashPass('admin'), role: 'admin' }] };
    saveAuth();
    addLog('warn', 'پیش‌فرض: admin/admin — رمز را عوض کنید!');
  }
}
function saveConfigs() { fs.writeFileSync(CONFIG_FILE, JSON.stringify(configs, null, 2)); }
function saveSettings() { fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2)); }
function saveAuth() { fs.writeFileSync(AUTH_FILE, JSON.stringify(auth, null, 2)); }
function hashPass(p) { return crypto.createHash('sha256').update(p + 'xray-bridge-salt-2024').digest('hex'); }

function addLog(level, msg) {
  const e = { time: new Date().toISOString(), level, msg };
  logs.unshift(e); if (logs.length > 1000) logs = logs.slice(0, 1000);
  process.stdout.write(`[${level.toUpperCase()}] ${msg}\n`);
}

function createSession(user) {
  const token = crypto.randomBytes(32).toString('hex');
  sessions[token] = { user, exp: Date.now() + 86400000 * 7 };
  return token;
}
function validateSession(token) {
  if (!token) return null;
  const s = sessions[token]; if (!s) return null;
  if (Date.now() > s.exp) { delete sessions[token]; return null; }
  return s.user;
}
function getToken(req) {
  const a = req.headers['authorization'] || '';
  if (a.startsWith('Bearer ')) return a.slice(7);
  const m = (req.headers['cookie'] || '').match(/xb_token=([a-f0-9]+)/);
  return m ? m[1] : null;
}

const PUBLIC = ['/api/login', '/api/login-info'];

function makeId() { return 'c' + Date.now().toString(36) + Math.random().toString(36).substr(2, 4); }
function baseDefaults() {
  return { delay: null, realDelay: null, status: 'unknown', active: false,
    addedAt: new Date().toISOString(), group: '', note: '', pingHistory: [] };
}

function parseVless(link) {
  try {
    const u = new URL(link), p = Object.fromEntries(u.searchParams);
    return { id: makeId(), name: decodeURIComponent(u.hash.slice(1)) || u.hostname, protocol: 'vless',
      address: u.hostname, port: parseInt(u.port) || 443, uuid: u.username,
      network: p.type || 'tcp', security: p.security || 'tls', sni: p.sni || p.host || u.hostname,
      path: p.path || '/', host: p.host || u.hostname, pbk: p.pbk || '', sid: p.sid || '',
      fp: p.fp || 'chrome', flow: p.flow || '', xhttpMode: p.mode || 'auto', xhttpExtra: '',
      dnsOverride: false, dns1: '', dns2: '', ...baseDefaults() };
  } catch { return null; }
}
function parseVmess(link) {
  try {
    const j = JSON.parse(Buffer.from(link.replace('vmess://', ''), 'base64').toString());
    return { id: makeId(), name: j.ps || j.add, protocol: 'vmess',
      address: j.add, port: parseInt(j.port) || 443, uuid: j.id, alterId: parseInt(j.aid) || 0,
      network: j.net || 'tcp', security: j.tls ? 'tls' : 'none', sni: j.sni || j.host || j.add,
      path: j.path || '/', host: j.host || j.add, pbk: '', sid: '', fp: '', flow: '',
      xhttpMode: 'auto', xhttpExtra: '', dnsOverride: false, dns1: '', dns2: '', ...baseDefaults() };
  } catch { return null; }
}
function parseTrojan(link) {
  try {
    const u = new URL(link), p = Object.fromEntries(u.searchParams);
    return { id: makeId(), name: decodeURIComponent(u.hash.slice(1)) || u.hostname, protocol: 'trojan',
      address: u.hostname, port: parseInt(u.port) || 443, uuid: u.username,
      network: p.type || 'tcp', security: p.security || 'tls', sni: p.sni || u.hostname,
      path: p.path || '/', host: p.host || u.hostname, pbk: '', sid: '', fp: p.fp || 'chrome', flow: '',
      xhttpMode: p.mode || 'auto', xhttpExtra: '', dnsOverride: false, dns1: '', dns2: '', ...baseDefaults() };
  } catch { return null; }
}
function parseSs(link) {
  try {
    const u = new URL(link); let method = 'aes-256-gcm', password = '';
    try { const d = Buffer.from(u.username, 'base64').toString(); [method, password] = d.split(':'); }
    catch { method = u.username; password = u.password; }
    return { id: makeId(), name: decodeURIComponent(u.hash.slice(1)) || u.hostname, protocol: 'shadowsocks',
      address: u.hostname, port: parseInt(u.port) || 8388, method: method || 'aes-256-gcm', password: password || '',
      uuid: '', network: 'tcp', security: 'none', sni: '', path: '/', host: '', pbk: '', sid: '', fp: '', flow: '',
      xhttpMode: 'auto', xhttpExtra: '', dnsOverride: false, dns1: '', dns2: '', ...baseDefaults() };
  } catch { return null; }
}
function parseLink(l) {
  l = l.trim();
  if (l.startsWith('vless://')) return parseVless(l);
  if (l.startsWith('vmess://')) return parseVmess(l);
  if (l.startsWith('trojan://')) return parseTrojan(l);
  if (l.startsWith('ss://')) return parseSs(l);
  return null;
}

function measureTcp(host, port, timeout = 5000) {
  return new Promise(resolve => {
    const start = Date.now(), sock = new net.Socket();
    sock.setTimeout(timeout);
    sock.connect(port, host, () => { const d = Date.now() - start; sock.destroy(); resolve(d); });
    sock.on('error', () => { sock.destroy(); resolve(null); });
    sock.on('timeout', () => { sock.destroy(); resolve(null); });
  });
}
function measureRealDelay() {
  return new Promise(resolve => {
    const start = Date.now(), sock = new net.Socket();
    sock.setTimeout(8000);
    sock.connect(settings.socksPort || 10808, '127.0.0.1', () => sock.write(Buffer.from([0x05, 0x01, 0x00])));
    let step = 0;
    sock.on('data', data => {
      if (step === 0 && data[0] === 5 && data[1] === 0) { step = 1; sock.write(Buffer.from([0x05, 0x01, 0x00, 0x01, 1, 1, 1, 1, 0x00, 0x50])); }
      else if (step === 1 && data[0] === 5 && data[1] === 0) { sock.destroy(); resolve(Date.now() - start); }
      else { sock.destroy(); resolve(null); }
    });
    sock.on('error', () => resolve(null));
    sock.on('timeout', () => { sock.destroy(); resolve(null); });
  });
}

async function testConfigDelay(cfg) {
  const delay = await measureTcp(cfg.address, cfg.port);
  let realDelay = null;
  if (activeConfigId === cfg.id && xrayProcess) realDelay = await measureRealDelay();
  if (delay !== null) {
    if (!cfg.pingHistory) cfg.pingHistory = [];
    cfg.pingHistory.push({ t: Date.now(), v: delay });
    if (cfg.pingHistory.length > 30) cfg.pingHistory = cfg.pingHistory.slice(-30);
  }
  return { delay, realDelay };
}

async function runDelayTests() {
  for (const cfg of configs) {
    const { delay, realDelay } = await testConfigDelay(cfg);
    cfg.delay = delay; if (realDelay !== null) cfg.realDelay = realDelay;
    cfg.status = delay !== null ? 'ok' : 'error';
  }
  saveConfigs();
  if (settings.autoSwitch) {
    const avail = configs.filter(c => c.delay !== null).sort((a, b) => a.delay - b.delay);
    if (avail.length && avail[0].id !== activeConfigId) {
      addLog('info', `Auto-switch → "${avail[0].name}" ${avail[0].delay}ms`);
      await activateConfig(avail[0].id);
    }
  }
}

function buildStreamSettings(cfg) {
  const ss = { network: cfg.network || 'tcp', security: cfg.security || 'tls' };
  if (cfg.security === 'tls') ss.tlsSettings = { serverName: cfg.sni || cfg.address, allowInsecure: false, fingerprint: cfg.fp || 'chrome' };
  if (cfg.security === 'reality') ss.realitySettings = { serverName: cfg.sni || 'www.google.com', fingerprint: cfg.fp || 'chrome', publicKey: cfg.pbk || '', shortId: cfg.sid || '', spiderX: '' };
  if (cfg.network === 'ws') ss.wsSettings = { path: cfg.path || '/', headers: { Host: cfg.host || cfg.sni || cfg.address } };
  if (cfg.network === 'grpc') ss.grpcSettings = { serviceName: (cfg.path || '').replace(/^\//, '') };
  if (cfg.network === 'h2') ss.httpSettings = { path: cfg.path || '/', host: [cfg.host || cfg.address] };
  if (cfg.network === 'xhttp' || cfg.network === 'splithttp') {
    const x = { host: cfg.host || cfg.sni || cfg.address, path: cfg.path || '/', mode: cfg.xhttpMode || 'auto' };
    if (cfg.xhttpExtra) { try { x.extra = JSON.parse(cfg.xhttpExtra); } catch { } }
    ss.xhttpSettings = x; ss.network = 'xhttp';
  }
  return ss;
}

function buildOutbound(cfg) {
  const ss = buildStreamSettings(cfg);
  if (cfg.protocol === 'vless') return { protocol: 'vless', settings: { vnext: [{ address: cfg.address, port: cfg.port, users: [{ id: cfg.uuid, flow: cfg.flow || '', encryption: 'none', level: 0 }] }] }, streamSettings: ss };
  if (cfg.protocol === 'vmess') return { protocol: 'vmess', settings: { vnext: [{ address: cfg.address, port: cfg.port, users: [{ id: cfg.uuid, alterId: cfg.alterId || 0, security: 'auto', level: 0 }] }] }, streamSettings: ss };
  if (cfg.protocol === 'trojan') return { protocol: 'trojan', settings: { servers: [{ address: cfg.address, port: cfg.port, password: cfg.uuid, level: 0 }] }, streamSettings: ss };
  if (cfg.protocol === 'shadowsocks') return { protocol: 'shadowsocks', settings: { servers: [{ address: cfg.address, port: cfg.port, method: cfg.method || 'aes-256-gcm', password: cfg.password, level: 0 }] } };
  return {};
}

function buildXrayConfig(cfgId) {
  const cfg = configs.find(c => c.id === cfgId);
  if (!cfg) return null;
  const ob = buildOutbound(cfg); ob.tag = 'proxy';
  if (settings.mux && cfg.network !== 'xhttp') ob.mux = { enabled: true, concurrency: 8 };
  const rules = [];
  if (settings.routeIranDirect) {
    rules.push({ type: 'field', ip: ['geoip:ir'], outboundTag: 'direct' });
    rules.push({ type: 'field', domain: ['geosite:ir'], outboundTag: 'direct' });
  }
  if (settings.blockAds) rules.push({ type: 'field', domain: ['geosite:category-ads-all'], outboundTag: 'block' });
  rules.push({ type: 'field', network: 'tcp,udp', outboundTag: 'proxy' });
  const d1 = (cfg.dnsOverride && cfg.dns1) ? cfg.dns1 : (settings.dns1 || '1.1.1.1');
  const d2 = (cfg.dnsOverride && cfg.dns2) ? cfg.dns2 : (settings.dns2 || '8.8.8.8');
  return {
    log: { loglevel: settings.logLevel || 'warning' },
    inbounds: [
      { tag: 'socks-in', port: settings.socksPort || 10808, listen: '0.0.0.0', protocol: 'socks', settings: { auth: 'noauth', udp: true } },
      { tag: 'http-in', port: settings.httpPort || 10809, listen: '0.0.0.0', protocol: 'http', settings: {} }
    ],
    outbounds: [ob, { tag: 'direct', protocol: 'freedom', settings: {} }, { tag: 'block', protocol: 'blackhole', settings: {} }],
    routing: { domainStrategy: settings.dnsStrategy || 'IPIfNonMatch', rules: [{ type: 'field', inboundTag: ['api-in'], outboundTag: 'api' }, ...rules] },
    dns: { servers: [d1, d2, { address: settings.localDns || '178.22.122.100', domains: ['geosite:ir'] }] }
  };
}

function isXrayInstalled() {
  try { execSync('which xray 2>/dev/null || ls /usr/local/bin/xray 2>/dev/null', { stdio: 'pipe' }); return true; } catch { return false; }
}
function getXrayVersion() {
  try { const o = execSync('xray version 2>&1 || /usr/local/bin/xray version 2>&1', { stdio: 'pipe' }).toString(); const m = o.match(/([\d]+\.[\d]+\.[\d]+)/); return m ? m[1] : 'installed'; } catch { return null; }
}

function installXray() {
  if (installProcess) return;
  installStatus = 'running'; installLog = [];
  const push = l => { installLog.push(l); if (installLog.length > 300) installLog = installLog.slice(-300); };
  push('▶ شروع نصب XRay Core...');
  installProcess = spawn('bash', ['-c', 'bash <(curl -L https://github.com/XTLS/Xray-install/raw/main/install-release.sh) @ install 2>&1'], { stdio: ['ignore', 'pipe', 'pipe'] });
  installProcess.stdout.on('data', d => d.toString().split('\n').filter(Boolean).forEach(l => { push(l); addLog('info', '[install] ' + l); }));
  installProcess.stderr.on('data', d => d.toString().split('\n').filter(Boolean).forEach(l => push('⚠ ' + l)));
  installProcess.on('exit', code => {
    installProcess = null;
    if (code === 0 || isXrayInstalled()) { installStatus = 'done'; push('✓ نصب موفق: v' + (getXrayVersion() || '')); addLog('info', 'XRay installed OK'); }
    else { installStatus = 'error'; push('✕ خطا — کد: ' + code); addLog('error', 'XRay install failed'); }
  });
}

async function activateConfig(cfgId) {
  const cfg = configs.find(c => c.id === cfgId);
  if (!cfg) return { ok: false, msg: 'Config not found' };
  const xrayCfg = buildXrayConfig(cfgId);
  fs.writeFileSync(XRAY_CONFIG_FILE, JSON.stringify(xrayCfg, null, 2));
  if (!isXrayInstalled()) {
    configs.forEach(c => c.active = false); cfg.active = true; activeConfigId = cfgId; saveConfigs();
    addLog('warn', `Simulation: "${cfg.name}"`);
    return { ok: true, msg: `"${cfg.name}" ذخیره شد (حالت شبیه‌سازی — XRay نصب نیست)`, simulation: true };
  }
  if (xrayProcess) { xrayProcess.kill('SIGTERM'); await new Promise(r => setTimeout(r, 600)); xrayProcess = null; }
  return new Promise(resolve => {
    xrayProcess = spawn('xray', ['run', '-c', XRAY_CONFIG_FILE], { stdio: ['ignore', 'pipe', 'pipe'] });
    let done = false;
    const finish = (ok, msg) => { if (!done) { done = true; resolve({ ok, msg }); } };
    const t = setTimeout(() => { configs.forEach(c => c.active = false); cfg.active = true; activeConfigId = cfgId; saveConfigs(); addLog('info', `XRay: "${cfg.name}"`); finish(true, `"${cfg.name}" فعال شد`); }, 2500);
    xrayProcess.stdout.on('data', d => { const l = d.toString().trim(); if (l) addLog('info', `[xray] ${l}`); if (!done && (l.includes('started') || l.includes('running') || l.includes('Xray'))) { clearTimeout(t); configs.forEach(c => c.active = false); cfg.active = true; activeConfigId = cfgId; saveConfigs(); finish(true, `"${cfg.name}" فعال شد`); } });
    xrayProcess.stderr.on('data', d => { const l = d.toString().trim(); if (l) addLog('warn', `[xray] ${l}`); });
    xrayProcess.on('exit', code => { addLog(code === 0 ? 'info' : 'error', `XRay exit ${code}`); xrayProcess = null; });
  });
}

function stopXray() { if (xrayProcess) { xrayProcess.kill('SIGTERM'); xrayProcess = null; } configs.forEach(c => c.active = false); activeConfigId = null; saveConfigs(); addLog('info', 'XRay stopped'); }
function startDelayLoop() { if (delayTestInterval) clearInterval(delayTestInterval); const ms = Math.max(3, settings.autoSwitchInterval || 5) * 1000; delayTestInterval = setInterval(runDelayTests, ms); }
function getXrayStatus() { if (!isXrayInstalled()) return 'not_installed'; return xrayProcess ? 'running' : 'stopped'; }
function getSysInfo() {
  const u = os.uptime(), m = os.totalmem(), f = os.freemem(), c = os.cpus();
  return { hostname: os.hostname(), platform: os.platform(), arch: os.arch(), uptime: u, uptimeStr: `${Math.floor(u / 86400)}d ${Math.floor((u % 86400) / 3600)}h ${Math.floor((u % 3600) / 60)}m`, totalMem: Math.round(m / 1024 / 1024), freeMem: Math.round(f / 1024 / 1024), usedMem: Math.round((m - f) / 1024 / 1024), memPercent: Math.round((m - f) / m * 100), cpuCount: c.length, cpuModel: (c[0] || {}).model || '', load1: os.loadavg()[0].toFixed(2) };
}
function get3xuiStats(xuiUrl, user, pass) {
  return new Promise(resolve => {
    let hostname, port, basePath;
    try { const u = new URL(xuiUrl || settings.xuiUrl || 'http://localhost:2053'); hostname = u.hostname; port = parseInt(u.port) || (u.protocol === 'https:' ? 443 : 80); basePath = u.pathname.replace(/\/$/, ''); } catch { return resolve({ ok: false, msg: 'Invalid URL' }); }
    const lb = JSON.stringify({ username: user || settings.xuiUser || 'admin', password: pass || settings.xuiPass || '' });
    const req = http.request({ hostname, port, path: basePath + '/login', method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(lb) } }, res => {
      let d = ''; const ck = (res.headers['set-cookie'] || []).map(c => c.split(';')[0]).join('; ');
      res.on('data', x => d += x);
      res.on('end', () => {
        try { if (!JSON.parse(d).success) return resolve({ ok: false, msg: 'Login failed' }); http.request({ hostname, port, path: basePath + '/xui/inbound/list', method: 'GET', headers: { Cookie: ck } }, r2 => { let d2 = ''; r2.on('data', x => d2 += x); r2.on('end', () => { try { resolve({ ok: true, data: JSON.parse(d2) }); } catch { resolve({ ok: false, msg: 'Parse error' }); } }); }).on('error', e => resolve({ ok: false, msg: e.message })).end(); } catch { resolve({ ok: false, msg: 'Parse error' }); }
      });
    });
    req.setTimeout(6000, () => { req.destroy(); resolve({ ok: false, msg: 'Timeout' }); });
    req.on('error', e => resolve({ ok: false, msg: e.message }));
    req.write(lb); req.end();
  });
}

function parseBody(req) { return new Promise(resolve => { let b = ''; req.on('data', d => b += d); req.on('end', () => { try { resolve(JSON.parse(b)); } catch { resolve({}); } }); }); }
function json(res, data, status = 200) { res.writeHead(status, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type,Authorization', 'Access-Control-Allow-Methods': 'GET,POST,DELETE,PUT,OPTIONS' }); res.end(JSON.stringify(data)); }
const MIME = { '.html': 'text/html;charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.ico': 'image/x-icon', '.json': 'application/json' };

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') { json(res, {}, 204); return; }
  const url = new URL(req.url, `http://localhost`), p = url.pathname;
  if (p.startsWith('/api/')) {
    const isPublic = PUBLIC.some(pp => p === pp);
    if (!isPublic) { const u = validateSession(getToken(req)); if (!u) return json(res, { ok: false, msg: 'Unauthorized', code: 401 }, 401); }

    if (req.method === 'POST' && p === '/api/login') { const b = await parseBody(req); const u = (auth.users || []).find(u => u.username === b.username); if (!u || u.password !== hashPass(b.password)) { addLog('warn', `Failed login: ${b.username}`); return json(res, { ok: false, msg: 'نام کاربری یا رمز اشتباه است' }, 401); } const token = createSession(u.username); addLog('info', `Login OK: ${u.username}`); return json(res, { ok: true, token, user: u.username, role: u.role }); }
    if (req.method === 'GET' && p === '/api/login-info') return json(res, { title: settings.loginTitle, subtitle: settings.loginSubtitle, logo: settings.loginLogo, bg: settings.loginBg, accent: settings.loginAccent, showVersion: settings.loginShowVersion, panelTitle: settings.panelTitle, loginBgImage: settings.loginBgImage, loginCustomCss: settings.loginCustomCss });
    if (req.method === 'POST' && p === '/api/logout') { const token = getToken(req); if (token) delete sessions[token]; return json(res, { ok: true }); }
    if (req.method === 'POST' && p === '/api/change-password') { const b = await parseBody(req); const un = validateSession(getToken(req)); const u = (auth.users || []).find(u => u.username === un); if (!u) return json(res, { ok: false, msg: 'Not found' }); if (u.password !== hashPass(b.oldPassword)) return json(res, { ok: false, msg: 'رمز فعلی اشتباه است' }, 400); if (!b.newPassword || b.newPassword.length < 6) return json(res, { ok: false, msg: 'حداقل ۶ کاراکتر' }, 400); u.password = hashPass(b.newPassword); saveAuth(); addLog('info', `Pass changed: ${un}`); return json(res, { ok: true }); }

    if (req.method === 'GET' && p === '/api/status') { const sys = getSysInfo(); return json(res, { xray: getXrayStatus(), xrayInstalled: isXrayInstalled(), xrayVersion: getXrayVersion(), activeConfigId, activeConfig: configs.find(c => c.id === activeConfigId) || null, configCount: configs.length, uptime: Math.floor(process.uptime()), mem: Math.round(process.memoryUsage().rss / 1024 / 1024), cpu: os.loadavg()[0].toFixed(2), autoSwitch: settings.autoSwitch, interval: settings.autoSwitchInterval, sys }); }
    if (req.method === 'GET' && p === '/api/sysinfo') return json(res, getSysInfo());
    if (req.method === 'GET' && p === '/api/configs') return json(res, configs);
    if (req.method === 'POST' && p === '/api/configs') {
      const b = await parseBody(req); let cfg;
      if (b.link) { cfg = parseLink(b.link); if (!cfg) return json(res, { ok: false, msg: 'Invalid link' }, 400); }
      else cfg = { id: makeId(), name: b.name || 'Unnamed', protocol: b.protocol || 'vless', address: b.address || '', port: parseInt(b.port) || 443, uuid: b.uuid || '', network: b.network || 'tcp', security: b.security || 'tls', sni: b.sni || b.address || '', path: b.path || '/', host: b.host || b.address || '', pbk: b.pbk || '', sid: b.sid || '', fp: b.fp || 'chrome', flow: b.flow || '', method: b.method || 'aes-256-gcm', password: b.password || b.uuid || '', alterId: parseInt(b.alterId) || 0, xhttpMode: b.xhttpMode || 'auto', xhttpExtra: b.xhttpExtra || '', dnsOverride: false, dns1: '', dns2: '', group: '', note: '', ...baseDefaults() };
      if (b.dnsOverride) { cfg.dnsOverride = true; cfg.dns1 = b.dns1 || ''; cfg.dns2 = b.dns2 || ''; }
      if (b.group) cfg.group = b.group; if (b.note) cfg.note = b.note;
      configs.push(cfg); saveConfigs(); addLog('info', `+Config: ${cfg.name}`); return json(res, { ok: true, config: cfg });
    }
    if (req.method === 'POST' && p === '/api/configs/bulk') {
      const b = await parseBody(req); const lines = (b.links || '').split('\n').map(l => l.trim()).filter(Boolean); const added = [], failed = [];
      for (const line of lines) { const cfg = parseLink(line); if (cfg) { if (b.group) cfg.group = b.group; configs.push(cfg); added.push(cfg); } else failed.push(line.substr(0, 80)); }
      saveConfigs(); addLog('info', `Bulk +${added.length}`); return json(res, { ok: true, added: added.length, failed: failed.length, failedLines: failed, configs: added });
    }
    if (req.method === 'PUT' && p.match(/^\/api\/configs\/[^/]+$/)) {
      const id = p.split('/')[3], cfg = configs.find(c => c.id === id); if (!cfg) return json(res, { ok: false, msg: 'Not found' }, 404);
      const b = await parseBody(req);
      ['name', 'note', 'group', 'dnsOverride', 'dns1', 'dns2', 'xhttpMode', 'xhttpExtra', 'flow', 'fp', 'sni', 'path', 'host', 'pbk', 'sid'].forEach(k => { if (b[k] !== undefined) cfg[k] = b[k]; });
      saveConfigs(); return json(res, { ok: true, config: cfg });
    }
    if (req.method === 'DELETE' && p.match(/^\/api\/configs\/[^/]+$/) && p.split('/').length === 4) { const id = p.split('/')[3]; const before = configs.length; configs = configs.filter(c => c.id !== id); if (configs.length < before) { saveConfigs(); if (activeConfigId === id) stopXray(); return json(res, { ok: true }); } return json(res, { ok: false, msg: 'Not found' }, 404); }
    if (req.method === 'DELETE' && p === '/api/configs') { configs = []; saveConfigs(); stopXray(); return json(res, { ok: true }); }
    if (req.method === 'POST' && p.match(/^\/api\/configs\/[^/]+\/activate$/)) { const id = p.split('/')[3]; return json(res, await activateConfig(id)); }
    if (req.method === 'POST' && p.match(/^\/api\/configs\/[^/]+\/test$/)) { const id = p.split('/')[3]; const cfg = configs.find(c => c.id === id); if (!cfg) return json(res, { ok: false, msg: 'Not found' }, 404); const { delay, realDelay } = await testConfigDelay(cfg); cfg.delay = delay; if (realDelay !== null) cfg.realDelay = realDelay; cfg.status = delay !== null ? 'ok' : 'error'; saveConfigs(); return json(res, { ok: true, delay, realDelay, status: cfg.status }); }
    if (req.method === 'GET' && p.match(/^\/api\/configs\/[^/]+\/history$/)) { const id = p.split('/')[3]; const cfg = configs.find(c => c.id === id); return json(res, cfg ? (cfg.pingHistory || []) : []); }
    if (req.method === 'POST' && p === '/api/start') { if (!configs.length) return json(res, { ok: false, msg: 'No configs' }); const best = configs.filter(c => c.delay !== null).sort((a, b) => a.delay - b.delay)[0] || configs[0]; return json(res, await activateConfig(best.id)); }
    if (req.method === 'POST' && p === '/api/stop') { stopXray(); return json(res, { ok: true }); }
    if (req.method === 'POST' && p === '/api/test-all') { await runDelayTests(); return json(res, { ok: true, configs }); }
    if (req.method === 'GET' && p === '/api/settings') return json(res, settings);
    if (req.method === 'POST' && p === '/api/settings') { const b = await parseBody(req); settings = { ...settings, ...b }; saveSettings(); startDelayLoop(); return json(res, { ok: true, settings }); }
    if (req.method === 'GET' && p === '/api/logs') { const lv = url.searchParams.get('level'); return json(res, (lv && lv !== 'all' ? logs.filter(l => l.level === lv) : logs).slice(0, 300)); }
    if (req.method === 'DELETE' && p === '/api/logs') { logs = []; return json(res, { ok: true }); }
    if (req.method === 'POST' && p === '/api/xray/install') { if (installStatus === 'running') return json(res, { ok: false, msg: 'در حال نصب است' }); installXray(); return json(res, { ok: true, msg: 'نصب شروع شد' }); }
    if (req.method === 'GET' && p === '/api/xray/install-status') return json(res, { status: installStatus, log: installLog, installed: isXrayInstalled(), version: getXrayVersion() });
    if (req.method === 'POST' && p === '/api/xray/uninstall') { exec('bash <(curl -sL https://github.com/XTLS/Xray-install/raw/main/install-release.sh) @ remove 2>&1', (e, o) => addLog('info', 'uninstall: ' + (e ? 'err' : 'ok'))); return json(res, { ok: true }); }
    if (req.method === 'GET' && p === '/api/xray-config') return json(res, activeConfigId ? buildXrayConfig(activeConfigId) || {} : {});
    if (req.method === 'POST' && p === '/api/3xui/test') { const b = await parseBody(req); const r = await get3xuiStats(b.url, b.user, b.pass); if (r.ok) { settings.xuiUrl = b.url || settings.xuiUrl; settings.xuiUser = b.user || settings.xuiUser; settings.xuiPass = b.pass || settings.xuiPass; saveSettings(); } return json(res, r); }

    return json(res, { ok: false, msg: 'Not found' }, 404);
  }

  let fp = path.join(__dirname, 'public', p === '/' ? 'index.html' : p);
  fs.stat(fp, (e, s) => { if (e || !s.isFile()) fp = path.join(__dirname, 'public', 'index.html'); fs.readFile(fp, (e2, d) => { if (e2) { res.writeHead(404); res.end('404'); return; } res.writeHead(200, { 'Content-Type': MIME[path.extname(fp)] || 'text/plain' }); res.end(d); }); });
});

loadData(); server.listen(PORT, '0.0.0.0', () => { addLog('info', `Panel → http://0.0.0.0:${PORT}`); addLog('info', `XRay: ${isXrayInstalled() ? 'v' + getXrayVersion() : 'not installed'}`); startDelayLoop(); setTimeout(runDelayTests, 3000); });
process.on('SIGTERM', () => { stopXray(); process.exit(0); });
process.on('SIGINT', () => { stopXray(); process.exit(0); });
